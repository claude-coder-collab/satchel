Why are the audio files in this archive FLAC?

This archive was created with Satchel 0.1.0.

To make the transfer smaller, uncompressed audio files were losslessly
compressed to FLAC. No audio quality has been lost. You can play and edit
the FLAC files as they are.

The original files - including all their metadata (timecode, scene/take
information, markers and everything else) - are stored inside the FLAC
files and can be restored bit-for-bit.

To get your original files back:
  1. Go to https://claude-coder-collab.github.io/satchel/
  2. Open this .zip file there. It runs in your web browser, is free,
     and needs no installation.
  3. Extract. Your original files are restored and verified.

Alternative for single .flac files (not *_chNN.flac sets): the free FLAC
command-line tool (https://xiph.org/flac/, version 1.4.3 or later) can
restore them:
  flac -d --keep-foreign-metadata take1.flac

Files that were converted:
  stereo.flac -> stereo.wav
